package com.th.TechHunters.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.th.TechHunters.model.News;
import com.th.TechHunters.repository.NewsMongoDBRepository;

@Service
public class NewsService {
	@Autowired
	private NewsMongoDBRepository NewsMongoDBRepository;

	public List<News> getPreviewAndTitleAndLink(String preview, String title, String link) {
		return NewsMongoDBRepository.findByPreviewAndTitleAndLink(preview, title, link);
	}

	public List<News> getList() {
		return NewsMongoDBRepository.findAll();
	}
	
}
