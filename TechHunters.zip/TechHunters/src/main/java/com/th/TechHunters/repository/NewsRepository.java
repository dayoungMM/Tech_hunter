package com.th.TechHunters.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.th.TechHunters.model.News;


public interface NewsRepository extends JpaRepository<News, Long> {
	public static News findByImageAndTitleAndLink(String image, String title, String link) {
		// TODO Auto-generated method stub
		return null;
	}
}
