package com.th.TechHunters.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.th.TechHunters.model.News;
import com.th.TechHunters.repository.NewsRepository;

@Controller
public class NewsControlller {
	@Autowired
	NewsRepository newsRepository;

	@Autowired
	HttpSession session;

	@GetMapping({ "/ainews" })
	public String index() {
		return "ainews";
	}

	@PostMapping("/ainews")
	public String signinPost(@ModelAttribute News news) {
		News dbnews = (News) NewsRepository.findByImageAndTitleAndLink(news.getImage(), news.getTitle(),
				news.getLink());
		if (dbnews != null) {
			session.setAttribute("news_info", dbnews);
		}
		return "redirect:/";
	}
}